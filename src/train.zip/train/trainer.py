#!/usr/bin/env python3
import os
import signal
import tempfile
import atexit
import torch
import torch.nn as nn
import numpy as np
from torch_geometric.data import Batch, Data
import swanlab

class GraphDataCollator:
    def __init__(self, max_points=200):
        self.max_points = max_points
        
    def __call__(self, batch):
        states, graphs, labels = [], [], []
        for batch_idx, (state, pc, label) in enumerate(batch):
            pos = torch.tensor(pc[:self.max_points], dtype=torch.float32)
            data = Data(pos=pos, batch=torch.full((len(pos),), batch_idx, dtype=torch.long))
            states.append(state)
            graphs.append(data)
            labels.append(label)
        return (
            torch.tensor(np.array(states), dtype=torch.float32),
            Batch.from_data_list(graphs),
            torch.tensor(np.array(labels), dtype=torch.float32)
        )

class ModelSaver:
    """ 完全合规的规范化实验路径热备份管理器 """
    def __init__(self, model, experiment_dir):
        self.model = model
        self.experiment_dir = experiment_dir
        self.should_save = False
        self.save_lock = False
        
        # 建立保存的物理文件夹
        if not os.path.exists(self.experiment_dir):
            os.makedirs(self.experiment_dir)
            print(f"-> Created compliance checkpoint warehouse: {self.experiment_dir}")
            
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
        atexit.register(self.cleanup_save)

    def signal_handler(self, sig, frame):
        print("\n[信号拦截] 捕获系统紧急终止指令，开始执行原子快照...")
        self.should_save = True

    def save_checkpoint(self, checkpoint_name):
        """ 对应你的规范：将模型 state_dict 固化到具体的名称 pt """
        if self.save_lock:
            return
        try:
            self.save_lock = True
            model_fn = f"{self.experiment_dir}/{checkpoint_name}.pt"
            
            # 使用临时文件做原子替换操作，防止突然断电生成 0KB 坏损文件
            with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
                tmp_path = tmp_file.name
                state_dict = {k: v.cpu().detach().clone() for k, v in self.model.state_dict().items()}
                torch.save(state_dict, tmp_path)
                os.replace(tmp_path, model_fn)
                print(f"🎉 成功同步物理资产！保存标记为: [{checkpoint_name}.pt]")
        except Exception as e:
            print(f"⚠️ 保存中断故障: {str(e)}")
        finally:
            self.save_lock = False
            self.should_save = False

    def cleanup_save(self):
        if not self.should_save:
            self.save_checkpoint("model_interrupted_backup")

def train_epoch(model, train_loader, optimizer, criterion_ctrl, criterion_risk, 
                saver, args, scheduler, device, epoch, best_tracker):
    """ 多任务物理信息前向-反向梯度闭环优化回路 """
    model.train()
    scaler = torch.amp.GradScaler()
    
    total_loss, total_loss_ctrl, total_loss_risk = 0.0, 0.0, 0.0
    
    for states, graph_batch, labels in train_loader:
        if saver.should_save:
            saver.save_checkpoint(f"epoch_interrupt_step_{epoch}")

        states = states.to(device, non_blocking=True)
        graph_batch = graph_batch.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
            true_action = labels[:, :2]  # 控制指令 (v, w)
            true_psi = labels[:, 2:3]     # 几何安全度 \psi
            risk_target = 1.0 - true_psi # 线性互补防御靶点
            
            pred_action, pred_risk = model(states, graph_batch)
            
            loss_ctrl = criterion_ctrl(pred_action, true_action)
            loss_risk = criterion_risk(pred_risk, risk_target)
            loss = loss_ctrl + args.lambda_risk * loss_risk
        
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0)
        
        scaler.step(optimizer)
        scaler.update()
        optimizer.zero_grad(set_to_none=True)
        
        if scheduler:
            scheduler.step()
            
        total_loss += loss.item()
        total_loss_ctrl += loss_ctrl.item()
        total_loss_risk += loss_risk.item()

    # 统计单 Epoch 的平均表现
    num_batches = len(train_loader)
    avg_loss = total_loss / num_batches
    avg_loss_ctrl = total_loss_ctrl / num_batches
    avg_loss_risk = total_loss_risk / num_batches
    lr = optimizer.param_groups[0]['lr']
    
    print(f"Epoch [{epoch+1}/{args.num_epochs}] | Combined: {avg_loss:.4f} | "
          f"Ctrl Huber: {avg_loss_ctrl:.4f} | Risk MSE: {avg_loss_risk:.4f}")

    # 🔴 SwanLab 动态上报远程工作空间看板
    if args.swanlab:
        swanlab.log({
            "Loss/Total_Combined": avg_loss,
            "Loss/Action_Imitation_Huber": avg_loss_ctrl,
            "Loss/Safety_Complementary_MSE": avg_loss_risk,
            "Optimization/Adaptive_Learning_Rate": lr
        }, step=epoch)

    # 🔴【核心保存审计对齐】执行基于你给出的周期的、以及最安全模型判定保存逻辑
    # 单卡数据生成类似RL，此处用物理风险最低（即对障碍物最警觉、风险误差最小）作为 Best 评定准则
    time_to_save = (epoch + 1) % args.num_epoch_save == 0
    if time_to_save:
        # 如果当前的几何风险预测误差小于历史最好水平，判定触发“model_best”
        if avg_loss_risk < best_tracker["best_risk_loss"]:
            best_tracker["best_risk_loss"] = avg_loss_risk
            print(f"🔥 检测到更高价值的安全觉醒平流层！当前最佳风险误差降低至: {avg_loss_risk:.5f}")
            saver.save_checkpoint("model_best")