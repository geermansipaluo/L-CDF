#!/usr/bin/env python3
from argument import get_args
# 🔴【最高优先级拦截】立刻截获并锁定训练所绑定的单张显卡，杜绝外部抢点竞争
args = get_args()
import os
os.environ["CUDA_VISIBLE_DEVICES"] = args.cuda_device

import random
import torch
import torch.nn as nn
import numpy as np
from torch.utils.data import DataLoader
from timm.optim import Lion
from torch.optim.lr_scheduler import OneCycleLR
import swanlab
swanlab.login(api_key="qxLMN0eaBQlXUoiWGKXux")
from model import DensityNet
from trainer import GraphDataCollator, ModelSaver, train_epoch

def set_seed(seed):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def load_data(dataset_path):
    data = np.load(dataset_path, allow_pickle=True)
    X, y, z = data['X'], data['y'], data['z']
    states = X[:, :4] # 平移旋转不变特征
    pointclouds = [np.array(pc) for pc in z]
    labels = y[:, :3]  # (v, omega, psi)
    return (states, pointclouds), labels

def main():
    set_seed(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"⚡ 纯单卡开发环境激活成功 -> 当前物理显卡独占绑定卡槽: {device}")

    # 数据解析加装
    (states, pointclouds), labels = load_data(args.dataset_path)
    dataset = list(zip(states, pointclouds, labels))
    
    train_loader = DataLoader(
        dataset, batch_size=args.batch_size, shuffle=True,  
        collate_fn=GraphDataCollator(args.max_points),
        num_workers=4, pin_memory=True, persistent_workers=True
    )

    # 4. 模型架构和多任务 Criterion 配置
    model = DensityNet(state_dim=4, hidden_dim=512).to(device)
    criterion_ctrl = nn.HuberLoss(delta=1.0)
    criterion_risk = nn.MSELoss()
    
    optimizer = Lion(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay, betas=(0.95, 0.98))
    scheduler = OneCycleLR(optimizer, max_lr=args.learning_rate*3, total_steps=args.num_epochs*len(train_loader), pct_start=0.3)

    # 🔴【核心路径对齐】使用你在 argument 中动态组装好的高隔离度实验文件夹
    saver = ModelSaver(model, args.experiment_dir)

    # 🔴【核心 SwanLab 看板对齐】按照你给出的标准参数，建立多任务流远程初始化连接
    if args.swanlab:
        swanlab.init(
            project=args.swanlab_project,
            experiment_name=args.swanlab_exp_name,
            config=vars(args),
            mode="cloud"  # 开启云端大画布实时画线
        )
        print(f"🚀 SwanLab 规范化大看板初始化成功！实验名称: {args.swanlab_exp_name}")

    # 设立历史最佳资产的监视字典 (用于保存 best 判定)
    best_tracker = {"best_risk_loss": float("inf")}

    # 开启自动化单卡流训练
    try:
        for epoch in range(args.num_epochs):
            train_epoch(
                model=model, train_loader=train_loader, optimizer=optimizer,
                criterion_ctrl=criterion_ctrl, criterion_risk=criterion_risk,
                saver=saver, args=args, scheduler=scheduler, device=device,
                epoch=epoch, best_tracker=best_tracker
            )
    except KeyboardInterrupt:
        print("\n[控制台介入] 用户手动干预终止，退出前向训练沙盒...")
    finally:
        saver.save_checkpoint("model_final_exit")
        if args.swanlab:
            swanlab.finish()
        print("🎉 实验结束，数据流清理圆满收官。")

if __name__ == "__main__":
    main()